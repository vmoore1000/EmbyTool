using System.Collections.Generic;
using MediaBrowser.Model.Plugins;

namespace Emby.Bulky.Configuration
{
    public class PluginConfiguration : BasePluginConfiguration
    {
        //No Configuration
        
        public PluginConfiguration()
        {
            

        }

    }
}
